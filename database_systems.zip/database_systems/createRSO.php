<?php

	include ("header.php");
	
	echo "Create RSO page";