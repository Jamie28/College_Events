<?php

	include("header.php");
	
	echo "Create event page";