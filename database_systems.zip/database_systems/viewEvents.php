<?php

	include ("header.php");
	
	echo "View events page";